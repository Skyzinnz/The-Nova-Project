#!/usr/bin/env bash
# Nova installer - Linux / Termux

set -e

NOVA_DIR="$HOME/nova"

echo "================================"
echo "  Nova Language Installer"
echo "================================"
echo ""

# ── Detect environment ───────────────────────
IS_TERMUX=false
if [ -n "$TERMUX_VERSION" ] || [ -d "/data/data/com.termux" ]; then
    IS_TERMUX=true
fi

# ── Check / install Python ───────────────────
if ! command -v python3 &>/dev/null; then
    echo "[*] Python3 not found. Installing..."
    if $IS_TERMUX; then
        pkg install python -y
    elif command -v apt &>/dev/null; then
        sudo apt install python3 -y
    elif command -v dnf &>/dev/null; then
        sudo dnf install python3 -y
    elif command -v pacman &>/dev/null; then
        sudo pacman -S python --noconfirm
    else
        echo "[!] Could not install Python automatically."
        echo "    Please install Python 3 manually and re-run this script."
        exit 1
    fi
fi

PYTHON=$(command -v python3)
echo "[+] Python found: $($PYTHON --version)"

# ── Copy files ───────────────────────────────
echo "[*] Installing Nova to $NOVA_DIR ..."
mkdir -p "$NOVA_DIR/core"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$SCRIPT_DIR/nova.py"       "$NOVA_DIR/nova.py"
cp "$SCRIPT_DIR/core/"*.py     "$NOVA_DIR/core/"
echo "[+] Files copied."

# ── Create launcher ──────────────────────────
if $IS_TERMUX; then
    # Termux: write directly to $PREFIX/bin (no sudo needed)
    NOVA_BIN="$PREFIX/bin/nova"
    cat > "$NOVA_BIN" << LAUNCHER
#!/usr/bin/env bash
exec $PYTHON "$NOVA_DIR/nova.py" "\$@"
LAUNCHER
    chmod +x "$NOVA_BIN"
    echo "[+] Launcher created: $NOVA_BIN"
else
    # Linux: try /usr/local/bin with sudo, fall back to ~/bin
    NOVA_BIN="/usr/local/bin/nova"
    LAUNCHER_TMP="$NOVA_DIR/nova_launcher"
    cat > "$LAUNCHER_TMP" << LAUNCHER
#!/usr/bin/env bash
exec $PYTHON "$NOVA_DIR/nova.py" "\$@"
LAUNCHER
    chmod +x "$LAUNCHER_TMP"
    if command -v sudo &>/dev/null; then
        sudo cp "$LAUNCHER_TMP" "$NOVA_BIN" && sudo chmod +x "$NOVA_BIN" \
            && echo "[+] Launcher created: $NOVA_BIN" \
            || _fallback=true
    else
        _fallback=true
    fi
    if [ "${_fallback:-false}" = true ]; then
        mkdir -p "$HOME/bin"
        cp "$LAUNCHER_TMP" "$HOME/bin/nova"
        chmod +x "$HOME/bin/nova"
        NOVA_BIN="$HOME/bin/nova"
        echo "[+] Launcher created: $NOVA_BIN"
        echo "[!] Add ~/bin to PATH if not already there:"
        echo "    export PATH=\"\$HOME/bin:\$PATH\""
    fi
fi

# ── Shell aliases ────────────────────────────
add_alias() {
    local cfg="$1"
    if [ -f "$cfg" ] && ! grep -q "alias nova=" "$cfg"; then
        echo "" >> "$cfg"
        echo "# Nova language" >> "$cfg"
        echo "alias nova='$PYTHON $NOVA_DIR/nova.py'" >> "$cfg"
        echo "[+] Alias added to $cfg"
    fi
}

add_alias "$HOME/.bashrc"
add_alias "$HOME/.bash_profile"
add_alias "$HOME/.zshrc"

FISH_CFG="$HOME/.config/fish/config.fish"
if [ -f "$FISH_CFG" ] && ! grep -q "alias nova" "$FISH_CFG"; then
    echo "" >> "$FISH_CFG"
    echo "# Nova language" >> "$FISH_CFG"
    echo "alias nova='$PYTHON $NOVA_DIR/nova.py'" >> "$FISH_CFG"
    echo "[+] Alias added to $FISH_CFG"
fi

# ── Done ─────────────────────────────────────
echo ""
echo "================================"
echo "  Nova installed successfully!"
echo "================================"
echo ""
echo "  nova --version"
echo "  nova myfile.nv"
echo "  nova edit myfile.nv"
echo ""
echo "  Restart your terminal or run:"
echo "  source ~/.bashrc"
echo ""
