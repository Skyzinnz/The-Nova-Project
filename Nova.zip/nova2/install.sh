#!/usr/bin/env bash
# Nova installer - Linux / Termux

set -e

NOVA_DIR="$HOME/nova"
NOVA_BIN=""

echo "================================"
echo "  Nova Language Installer"
echo "================================"
echo ""

# ── Detect environment ───────────────────────
IS_TERMUX=false
if [ -n "$TERMUX_VERSION" ] || [ -d "/data/data/com.termux" ]; then
    IS_TERMUX=true
fi

# ── Check / install Python ───────────────────
if ! command -v python3 &>/dev/null; then
    echo "[*] Python3 not found. Installing..."
    if $IS_TERMUX; then
        pkg install python -y
    elif command -v apt &>/dev/null; then
        sudo apt install python3 -y
    elif command -v dnf &>/dev/null; then
        sudo dnf install python3 -y
    elif command -v pacman &>/dev/null; then
        sudo pacman -S python --noconfirm
    else
        echo "[!] Could not install Python automatically."
        echo "    Please install Python 3 manually and re-run this script."
        exit 1
    fi
fi

PYTHON=$(command -v python3)
echo "[+] Python found: $($PYTHON --version)"

# ── Copy files ───────────────────────────────
echo "[*] Installing Nova to $NOVA_DIR ..."
mkdir -p "$NOVA_DIR/core"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$SCRIPT_DIR/nova.py"          "$NOVA_DIR/nova.py"
cp "$SCRIPT_DIR/core/"*.py        "$NOVA_DIR/core/"

echo "[+] Files copied."

# ── Create launcher script ───────────────────
if $IS_TERMUX; then
    NOVA_BIN="$PREFIX/bin/nova"
else
    NOVA_BIN="/usr/local/bin/nova"
fi

cat > /tmp/nova_launcher << LAUNCHER
#!/usr/bin/env bash
exec $PYTHON "$NOVA_DIR/nova.py" "\$@"
LAUNCHER

if $IS_TERMUX; then
    cp /tmp/nova_launcher "$NOVA_BIN"
    chmod +x "$NOVA_BIN"
else
    sudo cp /tmp/nova_launcher "$NOVA_BIN"
    sudo chmod +x "$NOVA_BIN"
fi

echo "[+] Launcher created: $NOVA_BIN"

# ── Shell config (alias fallback) ────────────
add_alias() {
    local cfg="$1"
    local line="alias nova='$PYTHON $NOVA_DIR/nova.py'"
    if [ -f "$cfg" ] && ! grep -q "alias nova=" "$cfg"; then
        echo "" >> "$cfg"
        echo "# Nova language" >> "$cfg"
        echo "$line" >> "$cfg"
        echo "[+] Alias added to $cfg"
    fi
}

add_alias "$HOME/.bashrc"
add_alias "$HOME/.bash_profile"
add_alias "$HOME/.zshrc"

# Fish shell
FISH_CFG="$HOME/.config/fish/config.fish"
if [ -f "$FISH_CFG" ] && ! grep -q "alias nova" "$FISH_CFG"; then
    echo "" >> "$FISH_CFG"
    echo "# Nova language" >> "$FISH_CFG"
    echo "alias nova='$PYTHON $NOVA_DIR/nova.py'" >> "$FISH_CFG"
    echo "[+] Alias added to $FISH_CFG"
fi

# ── Done ─────────────────────────────────────
echo ""
echo "================================"
echo "  Nova installed successfully!"
echo "================================"
echo ""
echo "  nova --version"
echo "  nova myfile.nv"
echo "  nova edit myfile.nv"
echo ""
echo "  Restart your terminal or run:"
echo "  source ~/.bashrc"
echo ""
