@echo off
:: Nova Language Installer for Windows
setlocal enabledelayedexpansion

echo ================================
echo   Nova Language Installer
echo ================================
echo.

:: ── Check Python ─────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Python not found.
    echo     Opening python.org in your browser...
    echo     After installing Python, re-run this script.
    echo     IMPORTANT: check "Add python.exe to PATH" during install!
    start https://www.python.org/downloads/
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('python --version') do set PYVER=%%i
echo [+] %PYVER% found.

:: ── Set install path ─────────────────────────
set NOVA_DIR=%USERPROFILE%\nova
echo [*] Installing Nova to %NOVA_DIR% ...

if not exist "%NOVA_DIR%\core" mkdir "%NOVA_DIR%\core"

:: ── Copy files ───────────────────────────────
copy /Y "%~dp0nova.py"       "%NOVA_DIR%\nova.py"      >nul
copy /Y "%~dp0core\*.py"     "%NOVA_DIR%\core\"        >nul
echo [+] Files copied.

:: ── Create nova.bat ──────────────────────────
set NOVA_BAT=%NOVA_DIR%\nova.bat
(
    echo @echo off
    echo python "%NOVA_DIR%\nova.py" %%*
) > "%NOVA_BAT%"
echo [+] Launcher created: %NOVA_BAT%

:: ── Add nova dir to user PATH ────────────────
echo [*] Adding %NOVA_DIR% to PATH...
setx PATH "%PATH%;%NOVA_DIR%" >nul 2>&1
echo [+] PATH updated.

:: ── Done ─────────────────────────────────────
echo.
echo ================================
echo   Nova installed successfully!
echo ================================
echo.
echo   Open a NEW Command Prompt and run:
echo   nova --version
echo   nova myfile.nv
echo   nova edit myfile.nv
echo.
pause
