#!/usr/bin/env python3
"""
Nova programming language - entry point
"""
import sys
import os

# Make sure core/ is importable regardless of where nova.py lives
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core import VERSION, Interpreter, nova_edit
from core.editor import _open_system_editor


def run_repl():
    print(f"Nova {VERSION}  (type 'help' for help, Ctrl+C to exit)")
    interp = Interpreter(source_dir=".")
    buf    = []
    depth  = 0
    while True:
        try:
            prompt = "... " if buf else ">>> "
            line   = input(prompt)
        except KeyboardInterrupt:
            print("\nBye.")
            break
        except EOFError:
            break

        depth += line.count("(") - line.count(")")
        buf.append(line)

        if depth <= 0:
            source = "\n".join(buf)
            buf    = []
            depth  = 0
            if source.strip():
                try:
                    interp.run_source(source)
                except Exception as e:
                    print(f"Error: {e}")


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print(f"Nova {VERSION}")
        print("Usage:")
        print("  nova <file.nv>               Run a Nova source file")
        print("  nova edit <file.nv> [mode]   Open file in editor")
        print("  nova                         Start the REPL")
        print("  nova -v / --version          Show version")
        return

    if args[0] in ("-v", "--version"):
        print(f"Nova {VERSION}")
        return

    # nova edit <file> [mode]
    if args[0] == "edit":
        if len(args) < 2:
            print("Usage: nova edit <file.nv> [auto|nova]")
            sys.exit(1)
        filepath = args[1]
        mode     = args[2] if len(args) > 2 else "auto"
        nova_edit(filepath, mode)
        return

    filepath = args[0]
    if not os.path.exists(filepath):
        print(f"nova: file not found: {filepath}")
        sys.exit(1)

    source_dir = str(os.path.dirname(os.path.abspath(filepath)))
    with open(filepath, "r", encoding="utf-8") as f:
        source = f.read()

    interp = Interpreter(source_dir=source_dir)
    try:
        interp.run_source(source)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        run_repl()
    else:
        main()
