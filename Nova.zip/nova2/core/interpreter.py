"""
Nova - Interpreter: executes Nova AST
"""

import sys, os, re, time, json, subprocess, importlib
import urllib.request, urllib.error
from .lexer import *
from .nodes import *
from .parser import Parser
from .runtime import *
from .help import HELP_PAGES

class RuntimeError_(Exception):
    pass

class Interpreter:
    def __init__(self, source_dir="."):
        self.source_dir   = source_dir
        self.global_scope = Scope()
        self.feed_mode    = False
        self.macros       = {}   # name -> raw code string
        self.groups       = {}   # name -> NovaGroup
        self.modules      = {}   # alias -> NovaModule
        self.events       = {}   # event_name -> list of body (stmts)
        self.serial_conns = {}   # port -> serial.Serial object
        self._bg_threads  = []
        self._setup_builtins()

    def _setup_builtins(self):
        import math, random
        self._math  = math
        self._random = random

    # ── Process escape sequences (/j /t /r)
    def _process_escapes(self, s: str) -> str:
        # /j*N
        s = re.sub(r'/j\*(\d+)', lambda m: "\n" * int(m.group(1)), s)
        # /j
        s = s.replace("/j", "\n")
        s = s.replace("/t", "\t")
        s = s.replace("/r", "\r")
        s = s.replace("//", "/")
        return s

    # ── Evaluate f-string
    def _eval_fstring(self, template: str, scope: Scope) -> str:
        def replacer(m):
            expr_src = m.group(1)
            try:
                toks  = Lexer(expr_src).tokenize()
                node  = Parser(toks).parse_expr()
                val   = self.eval_expr(node, scope)
                return self._to_str(val)
            except Exception as e:
                return f"<error:{e}>"
        result = re.sub(r'\{([^}]+)\}', replacer, template)
        return self._process_escapes(result)

    def _to_str(self, val) -> str:
        if val is None:   return "null"
        if val is True:   return "true"
        if val is False:  return "false"
        if isinstance(val, list): return "[" + ", ".join(self._to_str(v) for v in val) + "]"
        if isinstance(val, dict): return "{" + ", ".join(f"{k}: {self._to_str(v)}" for k,v in val.items()) + "}"
        return str(val)

    def _to_bool(self, val) -> bool:
        if val is None or val is False: return False
        if val == 0 or val == "" or val == [] or val == {}: return False
        return True

    # ── String method dispatch
    def _string_method(self, s, method, args):
        if method == "upper":   return s.upper()
        if method == "lower":   return s.lower()
        if method == "strip":   return s.strip()
        if method == "len":     return len(s)
        if method == "replace": return s.replace(args[0], args[1])
        if method == "split":   return s.split(args[0]) if args else s.split()
        if method == "starts":  return s.startswith(args[0])
        if method == "ends":    return s.endswith(args[0])
        if method == "find":    return s.find(args[0])
        if method == "slice":   return s[args[0]:args[1]]
        if method == "join":    return s.join([self._to_str(x) for x in args[0]])
        if method == "contains": return args[0] in s
        if method == "as_int":  return int(s)
        if method == "as_float": return float(s)
        if method == "as_str":  return s
        if method == "as_bool": return bool(s)
        raise RuntimeError_(f"Unknown string method: {method}")

    # ── List method dispatch
    def _list_method(self, lst, method, args):
        if method == "append":  lst.append(args[0]); return None
        if method == "pop":     return lst.pop(args[0] if args else -1)
        if method == "len":     return len(lst)
        if method == "contains": return args[0] in lst
        if method == "reverse": lst.reverse(); return None
        if method == "sort":    lst.sort(); return None
        if method == "slice":   return lst[args[0]:args[1]]
        if method == "join":    return (args[0] if args else "").join(self._to_str(x) for x in lst)
        if method == "index":   return lst.index(args[0])
        if method == "remove":  lst.remove(args[0]); return None
        if method == "as_str":  return self._to_str(lst)
        raise RuntimeError_(f"Unknown list method: {method}")

    # ── Dict method dispatch
    def _dict_method(self, d, method, args):
        if method == "keys":    return list(d.keys())
        if method == "values":  return list(d.values())
        if method == "items":   return [[k,v] for k,v in d.items()]
        if method == "get":     return d.get(args[0], args[1] if len(args)>1 else None)
        if method == "set":     d[args[0]] = args[1]; return None
        if method == "has":     return args[0] in d
        if method == "delete":  del d[args[0]]; return None
        if method == "len":     return len(d)
        if method == "as_str":  return self._to_str(d)
        raise RuntimeError_(f"Unknown dict method: {method}")

    # ── Number method dispatch
    def _number_method(self, n, method, args):
        if method == "as_str":   return str(n)
        if method == "as_int":   return int(n)
        if method == "as_float": return float(n)
        if method == "abs":      return abs(n)
        raise RuntimeError_(f"Unknown number method: {method}")

    # ── Built-in functions
    def _call_builtin(self, name, args, scope):
        m = self._math
        r = self._random
        if name == "abs":      return abs(args[0])
        if name == "sqrt":     return m.sqrt(args[0])
        if name == "floor":    return m.floor(args[0])
        if name == "ceil":     return m.ceil(args[0])
        if name == "min":      return min(args[0], args[1]) if len(args)==2 else min(args[0])
        if name == "max":      return max(args[0], args[1]) if len(args)==2 else max(args[0])
        if name == "round":    return round(args[0], args[1] if len(args)>1 else 0)
        if name == "rand":     return r.random()
        if name == "randint":  return r.randint(int(args[0]), int(args[1]))
        if name == "len":      return len(args[0])
        if name == "str":      return self._to_str(args[0])
        if name == "int":      return int(args[0])
        if name == "float":    return float(args[0])
        if name == "bool":     return self._to_bool(args[0])
        if name == "type":
            v = args[0]
            if v is None: return "null"
            if isinstance(v, bool): return "bool"
            if isinstance(v, int): return "int"
            if isinstance(v, float): return "float"
            if isinstance(v, str): return "str"
            if isinstance(v, list): return "list"
            if isinstance(v, dict): return "dict"
            return "unknown"
        if name == "clear":
            print("\033[2J\033[H", end="", flush=True)
            return None
        if name == "exit" or name == "quit":
            import sys as _sys
            _sys.exit(0)
        if name == "ask":
            prompt = self._to_str(args[0]) if args else ""
            return input(self._process_escapes(prompt))
        if name == "shell":
            cmd = self._to_str(args[0])
            res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            return res.stdout.rstrip()
        if name == "env":
            return os.environ.get(self._to_str(args[0]), "")
        if name == "setenv":
            os.environ[self._to_str(args[0])] = self._to_str(args[1])
            return None
        if name == "getcwd":
            return os.getcwd()
        if name == "cd":
            os.chdir(self._to_str(args[0]))
            return None
        if name == "exists":
            return os.path.exists(self._to_str(args[0]))
        if name == "readfile":
            with open(self._to_str(args[0]), "r", encoding="utf-8") as f:
                return f.read()
        if name == "writefile":
            with open(self._to_str(args[0]), "w", encoding="utf-8") as f:
                f.write(self._to_str(args[1]))
            return None
        if name == "appendfile":
            with open(self._to_str(args[0]), "a", encoding="utf-8") as f:
                f.write(self._to_str(args[1]))
            return None
        # http namespace
        if name == "http.get":
            return self._http_get(args)
        if name == "http.post":
            return self._http_post(args)
        # fmt(number, decimals=2, sep=False)
        if name == "fmt":
            n    = args[0]
            decs = int(args[1]) if len(args) > 1 else 2
            sep  = args[2] if len(args) > 2 else False
            if sep:
                return f"{n:,.{decs}f}"
            return f"{n:.{decs}f}"
        # serial namespace (handled via SerialNode, but also callable)
        if name.startswith("serial."):
            action = name[7:]
            return self._serial_action(action, args)
        return None

    def _http_get(self, args):
        url = self._to_str(args[0])
        headers = args[1] if len(args) > 1 else {}
        req = urllib.request.Request(url, headers=headers if isinstance(headers, dict) else {})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = resp.read().decode("utf-8")
                status = resp.status
                try: j = json.loads(body)
                except: j = None
                return {"status": status, "body": body, "json": j}
        except Exception as e:
            return {"status": 0, "body": str(e), "json": None}

    def _http_post(self, args):
        url  = self._to_str(args[0])
        data = args[1] if len(args) > 1 else {}
        body = json.dumps(data).encode("utf-8") if isinstance(data, dict) else self._to_str(data).encode()
        req  = urllib.request.Request(url, data=body,
               headers={"Content-Type": "application/json"},
               method="POST")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                rb   = resp.read().decode("utf-8")
                try: j = json.loads(rb)
                except: j = None
                return {"status": resp.status, "body": rb, "json": j}
        except Exception as e:
            return {"status": 0, "body": str(e), "json": None}

    def _serial_action(self, action, args):
        """Handle serial port operations. Requires pyserial (get pyserial from pip install)."""
        try:
            import serial as _serial
        except ImportError:
            raise RuntimeError_("pyserial not installed. Run: get pyserial from pip install")

        if action == "list":
            try:
                from serial.tools import list_ports
                return [p.device for p in list_ports.comports()]
            except Exception as e:
                raise RuntimeError_(f"serial.list failed: {e}")

        if action == "open":
            port     = self._to_str(args[0])
            baud     = int(args[1]) if len(args) > 1 else 9600
            timeout  = float(args[2]) if len(args) > 2 else 1.0
            try:
                conn = _serial.Serial(port, baud, timeout=timeout)
                self.serial_conns[port] = conn
                return port
            except Exception as e:
                raise RuntimeError_(f"serial.open failed: {e}")

        if action == "write":
            port = self._to_str(args[0])
            data = self._to_str(args[1])
            conn = self.serial_conns.get(port)
            if conn is None:
                raise RuntimeError_(f"serial port '{port}' not open")
            conn.write(data.encode("utf-8"))
            return None

        if action == "read":
            port  = self._to_str(args[0])
            count = int(args[1]) if len(args) > 1 else 64
            conn  = self.serial_conns.get(port)
            if conn is None:
                raise RuntimeError_(f"serial port '{port}' not open")
            data = conn.read(count)
            return data.decode("utf-8", errors="replace")

        if action == "readline":
            port = self._to_str(args[0])
            conn = self.serial_conns.get(port)
            if conn is None:
                raise RuntimeError_(f"serial port '{port}' not open")
            return conn.readline().decode("utf-8", errors="replace").strip()

        if action == "close":
            port = self._to_str(args[0])
            conn = self.serial_conns.get(port)
            if conn:
                conn.close()
                del self.serial_conns[port]
            return None

        if action == "available":
            port = self._to_str(args[0])
            conn = self.serial_conns.get(port)
            if conn is None: return 0
            return conn.in_waiting

        raise RuntimeError_(f"Unknown serial action: {action}")

    # ── Evaluate expression
    def eval_expr(self, node, scope: Scope):
        if isinstance(node, NumberNode): return node.value
        if isinstance(node, StringNode): return self._process_escapes(node.value)
        if isinstance(node, FStringNode): return self._eval_fstring(node.value, scope)
        if isinstance(node, PStringNode): return self._eval_fstring(node.value, scope)  # prompt string with interpolation
        if isinstance(node, BoolNode):   return node.value
        if isinstance(node, NullNode):   return None

        if isinstance(node, TernaryNode):
            cond = self.eval_expr(node.cond, scope)
            return self.eval_expr(node.if_true if self._to_bool(cond) else node.if_false, scope)

        if isinstance(node, ListCompNode):
            iterable = self.eval_expr(node.iterable, scope)
            result = []
            for item in iterable:
                local = Scope(scope)
                local.declare(node.var, item)
                if node.condition is None or self._to_bool(self.eval_expr(node.condition, local)):
                    result.append(self.eval_expr(node.expr, local))
            return result

        if isinstance(node, ListNode):
            return [self.eval_expr(i, scope) for i in node.items]

        if isinstance(node, DictNode):
            d = {}
            for k, v in node.pairs:
                kv = self.eval_expr(k, scope)
                vv = self.eval_expr(v, scope)
                d[kv] = vv
            return d

        if isinstance(node, IdentNode):
            name = node.name
            # http namespace
            if name == "http":
                return "__http__"
            # builtin constants
            if name in ("abs","sqrt","floor","ceil","min","max","round","rand","randint",
                        "len","str","int","float","bool","type","fmt",
                        "ask","shell","env","setenv","getcwd","cd",
                        "exists","readfile","writefile","appendfile"):
                return f"__builtin__{name}"
            try:
                return scope.get(name)
            except NameError:
                raise RuntimeError_(f"Undefined: '{name}'")

        if isinstance(node, BinOpNode):
            return self._eval_binop(node, scope)

        if isinstance(node, UnaryOpNode):
            v = self.eval_expr(node.operand, scope)
            if node.op == "-": return -v
            if node.op == "not": return not self._to_bool(v)

        if isinstance(node, AttrNode):
            obj = self.eval_expr(node.obj, scope)
            if isinstance(obj, dict): return obj.get(node.attr)
            if isinstance(obj, NovaModule):
                try:
                    return obj.scope.get(node.attr)
                except NameError:
                    raise RuntimeError_(f"Module has no export '{node.attr}'")
            if obj == "__http__": return f"__builtin__http.{node.attr}"
            if isinstance(obj, str) and obj.startswith("__builtin__"):
                # chained attr like serial.open
                return f"{obj}.{node.attr}"
            raise RuntimeError_(f"Cannot get attribute '{node.attr}' on {type(obj).__name__}")

        if isinstance(node, MethodCallNode):
            obj    = self.eval_expr(node.obj, scope)
            method = node.method
            args   = [self.eval_expr(a, scope) for a in node.args]
            # namespace builtins: http.get(), serial.open(), etc.
            if obj == "__http__":
                return self._call_builtin(f"http.{method}", args, scope)
            if isinstance(obj, str) and obj.startswith("__builtin__"):
                return self._call_builtin(f"{obj[len('__builtin__'):]}.{method}", args, scope)
            if isinstance(obj, NovaModule):
                fn = obj.scope.get(method)
                return self._call_value(fn, args, scope)
            if isinstance(obj, str):    return self._string_method(obj, method, args)
            if isinstance(obj, list):   return self._list_method(obj, method, args)
            if isinstance(obj, dict):   return self._dict_method(obj, method, args)
            if isinstance(obj, (int, float)): return self._number_method(obj, method, args)
            raise RuntimeError_(f"No method '{method}' on {type(obj).__name__}")

        if isinstance(node, IndexNode):
            obj = self.eval_expr(node.obj, scope)
            idx = self.eval_expr(node.index, scope)
            if isinstance(obj, (list, str)): return obj[int(idx)]
            if isinstance(obj, dict):        return obj[idx]
            raise RuntimeError_(f"Cannot index {type(obj).__name__}")

        if isinstance(node, CallNode):
            func = self.eval_expr(node.func, scope)
            args = []
            for a in node.args:
                if isinstance(a, SpreadNode):
                    val = self.eval_expr(a.expr, scope)
                    if isinstance(val, list):
                        args.extend(val)
                    else:
                        raise RuntimeError_("Spread (...) requires a list")
                else:
                    args.append(self.eval_expr(a, scope))
            return self._call_value(func, args, scope)

        raise RuntimeError_(f"Cannot evaluate node: {type(node).__name__}")

    def _eval_binop(self, node, scope):
        op = node.op
        # short-circuit
        if op == "and":
            l = self.eval_expr(node.left, scope)
            return l if not self._to_bool(l) else self.eval_expr(node.right, scope)
        if op == "or":
            l = self.eval_expr(node.left, scope)
            return l if self._to_bool(l) else self.eval_expr(node.right, scope)

        l = self.eval_expr(node.left, scope)
        r = self.eval_expr(node.right, scope)

        if op == "+":
            if isinstance(l, str) or isinstance(r, str):
                return self._to_str(l) + self._to_str(r)
            return l + r
        if op == "-":  return l - r
        if op == "*":
            if isinstance(l, str) and isinstance(r, int): return l * r
            return l * r
        if op == "/":  return l / r
        if op == "//": return l // r
        if op == "%":  return l % r
        if op == "**": return l ** r
        if op == "==": return l == r
        if op == "!=": return l != r
        if op == "<":  return l < r
        if op == ">":  return l > r
        if op == "<=": return l <= r
        if op == ">=": return l >= r
        # bitwise
        if op == "&":  return int(l) & int(r)
        if op == "|":  return int(l) | int(r)
        if op == "^":  return int(l) ^ int(r)
        if op == "<<": return int(l) << int(r)
        if op == ">>": return int(l) >> int(r)
        raise RuntimeError_(f"Unknown operator: {op}")

    def _call_value(self, func, args, scope):
        # expand spread nodes
        expanded = []
        for a in args:
            if isinstance(a, list) and hasattr(a, '__spread__'):
                expanded.extend(a)
            else:
                expanded.append(a)
        args = expanded
        if isinstance(func, str) and func.startswith("__builtin__"):
            name = func[len("__builtin__"):]
            return self._call_builtin(name, args, scope)
        if isinstance(func, NovaFunction):
            return self._call_function(func, args)
        if callable(func):
            return func(*args)
        raise RuntimeError_(f"Not callable: {func!r}")

    def _call_function(self, func: NovaFunction, args):
        local = Scope(func.closure)
        for i, p in enumerate(func.params):
            if i < len(args):
                local.declare(p, args[i])
            elif p in func.defaults:
                local.declare(p, self.eval_expr(func.defaults[p], func.closure))
            else:
                raise RuntimeError_(f"Missing argument: '{p}'")
        try:
            self.exec_body(func.body, local)
        except ReturnSignal as r:
            return r.value
        return None

    # ── Execute a list of statements
    def exec_body(self, stmts, scope: Scope):
        for stmt in stmts:
            self.exec_stmt(stmt, scope)

    # ── Execute one statement
    def exec_stmt(self, node, scope: Scope):
        try:
            result = self._exec_stmt_inner(node, scope)
            if self.feed_mode:
                print("feed - Valid")
            return result
        except (BreakSignal, ContinueSignal, ReturnSignal):
            raise
        except Exception as e:
            if self.feed_mode:
                print(f"feed - Invalid {e}")
            else:
                raise

    def _exec_stmt_inner(self, node, scope: Scope):

        if isinstance(node, AssignNode):
            val = self.eval_expr(node.value, scope)
            if node.declare:
                scope.declare(node.name, val)
            else:
                scope.set(node.name, val)
            return val

        if isinstance(node, AugAssignNode):
            cur = scope.get(node.name)
            val = self.eval_expr(node.value, scope)
            op  = node.op[0]  # + - * /
            new = BinOpNode(NumberNode(cur), op, NumberNode(val))
            # direct calc
            if op == "+": res = cur + val
            elif op == "-": res = cur - val
            elif op == "*": res = cur * val
            elif op == "/": res = cur / val
            else: raise RuntimeError_(f"Unknown aug op: {node.op}")
            scope.set(node.name, res)
            return res

        if isinstance(node, DelNode):
            scope.delete(node.name)
            return None

        if isinstance(node, SayNode):
            parts = []
            for a in node.args:
                v = self.eval_expr(a, scope)
                parts.append(self._to_str(v))
            print("".join(parts))
            return None

        if isinstance(node, WaitNode):
            t = self.eval_expr(node.duration, scope)
            time.sleep(float(t))
            return None

        if isinstance(node, FeedNode):
            self.feed_mode = (node.mode == "on")
            return None

        if isinstance(node, ExecNode):
            return self._exec_target(node.target, scope)

        if isinstance(node, GetNode):
            return self._exec_get(node, scope)

        if isinstance(node, HelpNode):
            page = node.page.lower()
            content = HELP_PAGES.get(page, HELP_PAGES.get("index"))
            print(content)
            return None

        if isinstance(node, IfNode):
            for cond, body in node.branches:
                if self._to_bool(self.eval_expr(cond, scope)):
                    local = Scope(scope)
                    self.exec_body(body, local)
                    return None
            if node.else_body is not None:
                local = Scope(scope)
                self.exec_body(node.else_body, local)
            return None

        if isinstance(node, WhileNode):
            while self._to_bool(self.eval_expr(node.condition, scope)):
                local = Scope(scope)
                try:
                    self.exec_body(node.body, local)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue
            return None

        if isinstance(node, ForNode):
            iterable = self.eval_expr(node.iterable, scope)
            if not hasattr(iterable, "__iter__"):
                raise RuntimeError_(f"Not iterable")
            for item in iterable:
                local = Scope(scope)
                local.declare(node.var, item)
                try:
                    self.exec_body(node.body, local)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue
            return None

        if isinstance(node, BreakNode):    raise BreakSignal()
        if isinstance(node, ContinueNode): raise ContinueSignal()
        if isinstance(node, ReturnNode):
            raise ReturnSignal(self.eval_expr(node.value, scope))

        if isinstance(node, FuncDefNode):
            fn = NovaFunction(node.name, node.params, node.defaults, node.body, scope)
            scope.declare(node.name, fn)
            return fn

        if isinstance(node, GroupDefNode):
            g = NovaGroup(node.name, node.body)
            self.groups[node.name] = g
            scope.declare(node.name, g)
            return g

        if isinstance(node, MacroDefNode):
            self.macros[node.name] = node.code
            return None

        if isinstance(node, TryCatchNode):
            try:
                local = Scope(scope)
                self.exec_body(node.try_body, local)
            except (BreakSignal, ContinueSignal, ReturnSignal):
                raise
            except Exception as e:
                local = Scope(scope)
                local.declare(node.err_var, str(e))
                self.exec_body(node.catch_body, local)
            return None

        if isinstance(node, ImportNode):
            return self._exec_import(node, scope)

        if isinstance(node, ExportNode):
            # no-op in runtime; handled by module loader
            return None

        if isinstance(node, ConstNode):
            val = self.eval_expr(node.value, scope)
            scope.declare(node.name, val, constant=True)
            return val

        if isinstance(node, MatchNode):
            subject = self.eval_expr(node.subject, scope)
            matched = False
            for case_val, case_body in node.cases:
                cv = self.eval_expr(case_val, scope)
                if subject == cv:
                    local = Scope(scope)
                    self.exec_body(case_body, local)
                    matched = True
                    break
            if not matched and node.default_body is not None:
                local = Scope(scope)
                self.exec_body(node.default_body, local)
            return None

        if isinstance(node, BgNode):
            import threading
            body  = node.body
            interp = self
            def _run():
                local = Scope(interp.global_scope)
                try:
                    interp.exec_body(body, local)
                except Exception as e:
                    print(f"[bg error] {e}")
            t = threading.Thread(target=_run, daemon=True)
            t.start()
            interp._bg_threads.append(t)
            return None

        if isinstance(node, OnNode):
            if node.event not in self.events:
                self.events[node.event] = []
            self.events[node.event].append(node.body)
            return None

        if isinstance(node, EmitNode):
            args = [self.eval_expr(a, scope) for a in node.args]
            handlers = self.events.get(node.event, [])
            for body in handlers:
                local = Scope(scope)
                if args:
                    local.declare("__args__", args)
                self.exec_body(body, local)
            return None

        if isinstance(node, SerialNode):
            args = [self.eval_expr(a, scope) for a in node.args]
            return self._serial_action(node.action, args)

        if isinstance(node, EditNode):
            fp   = self.eval_expr(node.filepath, scope) if not isinstance(node.filepath, str) else node.filepath
            fp   = self._to_str(fp)
            nova_edit(fp, node.mode)
            return None

        # Macro call (ident that matches a macro, before eval_expr raises undefined)
        if isinstance(node, IdentNode) and node.name in self.macros:
            self._run_macro(node.name, scope)
            return None

        # Bare keyword builtins: clear, exit, quit (no parens needed)
        if isinstance(node, IdentNode) and node.name in ("clear", "exit", "quit"):
            return self._call_builtin(node.name, [], scope)

        # Expression statement
        result = self.eval_expr(node, scope)
        return result

    def _exec_target(self, target: str, scope: Scope):
        # macro
        if target in self.macros:
            self._run_macro(target, scope)
            return None

        # module.group
        if "." in target:
            mod_name, group_name = target.split(".", 1)
            if mod_name in self.modules:
                mod = self.modules[mod_name]
                g   = mod.scope.vars.get(group_name)
                if isinstance(g, NovaGroup):
                    self.exec_body(g.body, self.global_scope)
                    return None
            raise RuntimeError_(f"Module '{mod_name}' or group '{group_name}' not found")

        # group
        if target in self.groups:
            self.exec_body(self.groups[target].body, scope)
            return None

        # variable holding code string
        if scope.has(target):
            val = scope.get(target)
            if isinstance(val, str):
                self.run_source(val)
                return None
            if isinstance(val, NovaGroup):
                self.exec_body(val.body, scope)
                return None

        # file
        filepath = target if target.endswith(".nv") else target + ".nv"
        candidates = [filepath, os.path.join(self.source_dir, filepath)]
        for c in candidates:
            if os.path.exists(c):
                with open(c, "r", encoding="utf-8") as f:
                    self.run_source(f.read())
                return None
        raise RuntimeError_(f"Cannot exec '{target}': not a group, variable, or file")

    def _exec_get(self, node: GetNode, scope: Scope):
        if node.source == "pip":
            subprocess.run([sys.executable, "-m", "pip", "install", node.name], check=True)
        elif node.source == "source":
            print(f"[nova] Installing '{node.name}' from Nova registry (stub)...")
        elif node.source == "git":
            url = node.extra or ""
            subprocess.run(["git", "clone", url, node.name], check=True)
        elif node.source == "url":
            url = node.extra or node.name
            try:
                with urllib.request.urlopen(url, timeout=10) as r:
                    body = r.read().decode("utf-8")
                if node.mode == "var":
                    scope.declare(node.name, body)
            except Exception as e:
                raise RuntimeError_(f"GET request failed: {e}")
        return None

    def _exec_import(self, node: ImportNode, scope: Scope):
        filepath = node.filepath
        candidates = [filepath, os.path.join(self.source_dir, filepath)]
        for c in candidates:
            if os.path.exists(c):
                with open(c, "r", encoding="utf-8") as f:
                    src = f.read()
                sub = Interpreter(source_dir=os.path.dirname(c))
                sub.run_source(src)
                mod = NovaModule(sub.global_scope)
                self.modules[node.alias] = mod
                scope.declare(node.alias, mod)
                return None
        raise RuntimeError_(f"Cannot import '{node.filepath}': file not found")

    def _run_macro(self, name, scope):
        code = self.macros[name]
        self.run_source(code, scope=scope)

    def run_source(self, source: str, scope: Scope = None):
        if scope is None:
            scope = self.global_scope
        try:
            tokens = Lexer(source).tokenize()
            tree   = Parser(tokens).parse_program()
            for stmt in tree.statements:
                self.exec_stmt(stmt, scope)
        except (BreakSignal, ContinueSignal):
            pass
        except ReturnSignal as r:
            return r.value



