"""
Nova - Lexer: tokenizes Nova source into tokens
"""

TT_INT      = "INT"
TT_FLOAT    = "FLOAT"
TT_STRING   = "STRING"
TT_FSTRING  = "FSTRING"
TT_PSTRING  = "PSTRING"
TT_BOOL     = "BOOL"
TT_NULL     = "NULL"
TT_IDENT    = "IDENT"
TT_KEYWORD  = "KEYWORD"
TT_OP       = "OP"
TT_LPAREN   = "LPAREN"
TT_RPAREN   = "RPAREN"
TT_LBRACKET = "LBRACKET"
TT_RBRACKET = "RBRACKET"
TT_LBRACE   = "LBRACE"
TT_RBRACE   = "RBRACE"
TT_COMMA    = "COMMA"
TT_COLON    = "COLON"
TT_DOT      = "DOT"
TT_NEWLINE  = "NEWLINE"
TT_EOF      = "EOF"

KEYWORDS = {
    "var", "varcd", "say", "exec", "wait", "get", "from", "import",
    "group", "def", "return", "if", "elif", "else", "while", "for",
    "in", "range", "break", "continue", "and", "or", "not",
    "true", "false", "null", "try", "catch", "del", "export",
    "install", "source", "pip", "git", "url", "var",
    "feed", "ask", "shell", "env", "setenv", "getcwd", "cd",
    "exists", "readfile", "writefile", "appendfile", "help",
    "clear", "exit", "quit",
    # 0.2.0
    "const", "match", "case", "default", "bg", "on", "emit",
    "serial",
    # 0.3.0
    "edit",
}

class Token:
    def __init__(self, type_, value=None, line=0):
        self.type  = type_
        self.value = value
        self.line  = line
    def __repr__(self):
        return f"Token({self.type}, {self.value!r})"

class LexerError(Exception):
    pass

class Lexer:
    def __init__(self, source: str):
        self.source  = source
        self.pos     = 0
        self.line    = 1
        self.tokens  = []

    def error(self, msg):
        raise LexerError(f"[Line {self.line}] Lexer error: {msg}")

    def peek(self, offset=0):
        p = self.pos + offset
        return self.source[p] if p < len(self.source) else None

    def advance(self):
        ch = self.source[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
        return ch

    def skip_whitespace(self):
        while self.pos < len(self.source) and self.peek() in (" ", "\t", "\r"):
            self.advance()

    def skip_comment(self):
        while self.pos < len(self.source) and self.peek() != "\n":
            self.advance()

    def read_string(self, quote, fstring=False):
        self.advance()  # skip opening quote
        buf = ""
        while self.pos < len(self.source):
            ch = self.peek()
            if ch == "\\":
                self.advance()
                esc = self.advance()
                buf += {"n": "\n", "t": "\t", "r": "\r", "\\": "\\"}.get(esc, esc)
            elif ch == quote:
                self.advance()
                break
            elif ch == "\n":
                self.error("Unterminated string")
            else:
                buf += self.advance()
        return buf

    def make_token(self, type_, value=None):
        return Token(type_, value, self.line)

    def tokenize(self):
        src = self.source
        while self.pos < len(src):
            self.skip_whitespace()
            if self.pos >= len(src):
                break

            ch = self.peek()

            # newline
            if ch == "\n":
                self.advance()
                self.tokens.append(self.make_token(TT_NEWLINE))
                continue

            # block comment  ## ... ##
            if ch == "#" and self.peek(1) == "#":
                self.advance(); self.advance()
                while self.pos < len(src) - 1:
                    if self.peek() == "#" and self.peek(1) == "#":
                        self.advance(); self.advance()
                        break
                    self.advance()
                continue
            # line comment
            if ch == "#":
                self.skip_comment()
                continue

            # f-string
            if ch in ("f", "F") and self.peek(1) in ('"', "'"):
                self.advance()
                q = self.peek()
                s = self.read_string(q, fstring=True)
                self.tokens.append(self.make_token(TT_FSTRING, s))
                continue

            # p-string (prompt string)
            if ch in ("p", "P") and self.peek(1) in ('"', "'"):
                self.advance()
                q = self.peek()
                s = self.read_string(q)
                self.tokens.append(self.make_token(TT_PSTRING, s))
                continue

            # string
            if ch in ('"', "'"):
                s = self.read_string(ch)
                self.tokens.append(self.make_token(TT_STRING, s))
                continue

            # number
            if ch.isdigit() or (ch == "-" and self.peek(1) and self.peek(1).isdigit()
                                 and (not self.tokens or self.tokens[-1].type in
                                      (TT_OP, TT_COMMA, TT_LPAREN, TT_NEWLINE, TT_EOF, TT_KEYWORD))):
                num = ""
                if ch == "-":
                    num += self.advance()
                while self.pos < len(src) and self.peek() and (self.peek().isdigit()):
                    num += self.advance()
                if self.pos < len(src) and self.peek() == ".":
                    num += self.advance()
                    while self.pos < len(src) and self.peek() and self.peek().isdigit():
                        num += self.advance()
                    self.tokens.append(self.make_token(TT_FLOAT, float(num)))
                else:
                    self.tokens.append(self.make_token(TT_INT, int(num)))
                continue

            # identifier / keyword
            if ch.isalpha() or ch == "_":
                ident = ""
                while self.pos < len(src) and self.peek() and (self.peek().isalnum() or self.peek() in ("_",)):
                    ident += self.advance()
                if ident == "true":
                    self.tokens.append(self.make_token(TT_BOOL, True))
                elif ident == "false":
                    self.tokens.append(self.make_token(TT_BOOL, False))
                elif ident == "null":
                    self.tokens.append(self.make_token(TT_NULL, None))
                elif ident in KEYWORDS:
                    self.tokens.append(self.make_token(TT_KEYWORD, ident))
                else:
                    self.tokens.append(self.make_token(TT_IDENT, ident))
                continue

            # operators (two-char first)
            two = src[self.pos:self.pos+2]
            if two in ("==", "!=", "<=", ">=", "**", "//", "+=", "-=", "*=", "/=", "<<", ">>", "&=", "|="):
                self.pos += 2
                self.tokens.append(self.make_token(TT_OP, two))
                continue

            one_ops = set("+-*/%<>=!&|^~")
            if ch in one_ops:
                self.tokens.append(self.make_token(TT_OP, self.advance()))
                continue

            if ch == "(":
                self.advance(); self.tokens.append(self.make_token(TT_LPAREN)); continue
            if ch == ")":
                self.advance(); self.tokens.append(self.make_token(TT_RPAREN)); continue
            if ch == "[":
                self.advance(); self.tokens.append(self.make_token(TT_LBRACKET)); continue
            if ch == "]":
                self.advance(); self.tokens.append(self.make_token(TT_RBRACKET)); continue
            if ch == "{":
                self.advance(); self.tokens.append(self.make_token(TT_LBRACE)); continue
            if ch == "}":
                self.advance(); self.tokens.append(self.make_token(TT_RBRACE)); continue
            if ch == ",":
                self.advance(); self.tokens.append(self.make_token(TT_COMMA)); continue
            if ch == ":":
                self.advance(); self.tokens.append(self.make_token(TT_COLON)); continue
            if ch == ".":
                self.advance(); self.tokens.append(self.make_token(TT_DOT)); continue

            self.error(f"Unknown character: {ch!r}")

        self.tokens.append(self.make_token(TT_EOF))
        return self.tokens


