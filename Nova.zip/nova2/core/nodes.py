"""
Nova - AST nodes produced by the parser
"""

class Node:
    pass

class NumberNode(Node):
    def __init__(self, value): self.value = value

class StringNode(Node):
    def __init__(self, value): self.value = value

class FStringNode(Node):
    def __init__(self, value): self.value = value   # raw template

class PStringNode(Node):
    def __init__(self, value): self.value = value   # prompt string template

class BoolNode(Node):
    def __init__(self, value): self.value = value

class NullNode(Node):
    pass

class ListNode(Node):
    def __init__(self, items): self.items = items

class DictNode(Node):
    def __init__(self, pairs): self.pairs = pairs   # list of (key_node, val_node)

class IdentNode(Node):
    def __init__(self, name): self.name = name

class BinOpNode(Node):
    def __init__(self, left, op, right): self.left=left; self.op=op; self.right=right

class UnaryOpNode(Node):
    def __init__(self, op, operand): self.op=op; self.operand=operand

class AssignNode(Node):
    def __init__(self, name, value, declare=False):
        self.name=name; self.value=value; self.declare=declare

class AugAssignNode(Node):
    def __init__(self, name, op, value): self.name=name; self.op=op; self.value=value

class DelNode(Node):
    def __init__(self, name): self.name = name

class SayNode(Node):
    def __init__(self, args): self.args = args

class WaitNode(Node):
    def __init__(self, duration): self.duration = duration

class FeedNode(Node):
    def __init__(self, mode): self.mode = mode   # "on" or "off"

class ExecNode(Node):
    def __init__(self, target): self.target = target  # str or IdentNode

class GetNode(Node):
    def __init__(self, name, source, mode, extra=None):
        self.name=name; self.source=source; self.mode=mode; self.extra=extra

class HelpNode(Node):
    def __init__(self, page): self.page = page

class IfNode(Node):
    def __init__(self, branches, else_body):
        self.branches=branches    # list of (condition, body)
        self.else_body=else_body  # body or None

class WhileNode(Node):
    def __init__(self, condition, body): self.condition=condition; self.body=body

class ForNode(Node):
    def __init__(self, var, iterable, body): self.var=var; self.iterable=iterable; self.body=body

class BreakNode(Node): pass
class ContinueNode(Node): pass

class ReturnNode(Node):
    def __init__(self, value): self.value = value

class FuncDefNode(Node):
    def __init__(self, name, params, defaults, body):
        self.name=name; self.params=params; self.defaults=defaults; self.body=body

class GroupDefNode(Node):
    def __init__(self, name, body): self.name=name; self.body=body

class MacroDefNode(Node):
    def __init__(self, name, code): self.name=name; self.code=code

class MacroCallNode(Node):
    def __init__(self, name): self.name = name

class CallNode(Node):
    def __init__(self, func, args, kwargs=None):
        self.func=func; self.args=args; self.kwargs=kwargs or {}

class AttrNode(Node):
    def __init__(self, obj, attr): self.obj=obj; self.attr=attr

class MethodCallNode(Node):
    def __init__(self, obj, method, args): self.obj=obj; self.method=method; self.args=args

class IndexNode(Node):
    def __init__(self, obj, index): self.obj=obj; self.index=index

class TryCatchNode(Node):
    def __init__(self, try_body, err_var, catch_body):
        self.try_body=try_body; self.err_var=err_var; self.catch_body=catch_body

class ImportNode(Node):
    def __init__(self, alias, filepath): self.alias=alias; self.filepath=filepath

class ExportNode(Node):
    def __init__(self, name): self.name = name

class ShellNode(Node):
    def __init__(self, cmd): self.cmd = cmd

class ConstNode(Node):
    def __init__(self, name, value): self.name=name; self.value=value

class MatchNode(Node):
    def __init__(self, subject, cases, default_body):
        self.subject=subject; self.cases=cases; self.default_body=default_body

class TernaryNode(Node):
    def __init__(self, cond, if_true, if_false):
        self.cond=cond; self.if_true=if_true; self.if_false=if_false

class SpreadNode(Node):
    def __init__(self, expr): self.expr = expr

class ListCompNode(Node):
    def __init__(self, expr, var, iterable, condition=None):
        self.expr=expr; self.var=var; self.iterable=iterable; self.condition=condition

class BgNode(Node):
    def __init__(self, body): self.body = body

class OnNode(Node):
    def __init__(self, event, body): self.event=event; self.body=body

class EmitNode(Node):
    def __init__(self, event, args): self.event=event; self.args=args

class SerialNode(Node):
    def __init__(self, action, args): self.action=action; self.args=args

class EditNode(Node):
    def __init__(self, filepath, mode): self.filepath=filepath; self.mode=mode

class ProgramNode(Node):
    def __init__(self, statements): self.statements = statements


