"""
Nova - Runtime: Scope, signals, and value types
"""

class BreakSignal(Exception): pass
class ContinueSignal(Exception): pass
class ReturnSignal(Exception):
    def __init__(self, value): self.value = value

class NovaFunction:
    def __init__(self, name, params, defaults, body, closure):
        self.name=name; self.params=params; self.defaults=defaults
        self.body=body; self.closure=closure

class NovaGroup:
    def __init__(self, name, body): self.name=name; self.body=body

class NovaModule:
    def __init__(self, scope): self.scope = scope

class Scope:
    def __init__(self, parent=None):
        self.vars      = {}
        self.constants = set()
        self.parent    = parent

    def get(self, name):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        raise NameError(f"Undefined variable: '{name}'")

    def set(self, name, value):
        if name in self.vars:
            if name in self.constants:
                raise RuntimeError_(f"Cannot reassign constant '{name}'")
            self.vars[name] = value
            return
        if self.parent and self.parent.has(name):
            self.parent.set(name, value)
            return
        self.vars[name] = value   # create in current scope

    def declare(self, name, value, constant=False):
        self.vars[name] = value
        if constant:
            self.constants.add(name)

    def has(self, name):
        if name in self.vars:
            return True
        if self.parent:
            return self.parent.has(name)
        return False

    def delete(self, name):
        if name in self.vars:
            del self.vars[name]
        elif self.parent:
            self.parent.delete(name)


