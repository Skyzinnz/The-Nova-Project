"""
Nova - Help pages
"""

VERSION = "0.3.0"

import sys

HELP_PAGES = {}  # filled below

def _build():
    global HELP_PAGES
    HELP_PAGES = {
        "index": """
Nova Language Help - v{ver}
===========================

Available help pages:
  help vars        - Variables, const, and types
  help say         - Output to console
  help feed        - Feedback mode
  help exec        - Execute files and groups
  help wait        - Pause execution
  help get         - Package/resource fetching
  help flow        - if / elif / else / while / for
  help match       - match / case (switch)
  help func        - def (functions)
  help group       - Code groups
  help macro       - varcd (macros / shortcuts)
  help math        - Arithmetic, bitwise, expressions
  help strings     - String features (f-strings, /j)
  help input       - Reading user input
  help types       - Type casting and fmt
  help listcomp    - List comprehensions
  help spread      - Spread operator (...)
  help ternary     - Inline if expression
  help import      - Importing Nova modules
  help errors      - Error handling (try/catch)
  help os          - OS and shell integration
  help net         - HTTP requests
  help events      - on / emit event system
  help bg          - Background tasks
  help serial      - Serial port / Arduino
  help edit        - Built-in editor
  help version     - Language version info

Type  help <page>  for details.
""".format(ver=VERSION),

        "vars": """
Variables and Constants
-----------------------
Declare a variable:
  var <name> = <value>

Declare a constant (cannot be reassigned):
  const <name> = <value>

Types: str, int, float, bool, list, dict, null

Examples:
  var name     = "Alice"
  var age      = 30
  var pi       = 3.14
  var on       = true
  var data     = [1, 2, 3]
  var cfg      = {key: "val"}
  var nothing  = null
  const MAX    = 100
  const APPNAME = "MyApp"

Reassign without var:
  name = "Bob"

Delete a variable:
  del <name>
""",

        "say": """
Output - say
------------
Print text or values to the console.

Usage:
  say("<text>")
  say(<var>)
  say("<text>" + <var> + "<text>")
  say(f"Hello {name}, you are {age} years old")

Multi-line form:
  say(
    "line one",
    var1,
    "line two"
  )

Line breaks:
  /j          - one newline
  /j*N        - N newlines  (e.g. /j*3)
  /t          - tab
""",

        "feed": """
Feedback Mode - feed
--------------------
Prints validation status after each statement.

  feed.on       - enable  (feed - Valid / feed - Invalid <error>)
  feed.off      - disable (default)
""",

        "exec": """
Execute - exec
--------------
Run a Nova file or an inline code variable or a group.

  exec <file.nv>            - run a Nova source file
  exec <var>                - run code stored in a variable
  exec <groupname>          - run a defined group
  exec <module>.<group>     - run group from imported module
""",

        "wait": """
Wait - wait
-----------
Pause execution for a given number of seconds.

  wait <seconds>
  wait 0.5
  wait 2
""",

        "get": """
Package / Resource Fetching - get
----------------------------------
Install from pip:
  get <pkg> from pip install

Install from Git:
  get <pkg> from git <url> install

Fetch URL into variable:
  get <varname> from url <url> var
""",

        "flow": """
Control Flow
------------
if / elif / else:
  if <condition>(
    ...
  ) elif <condition>(
    ...
  ) else(
    ...
  )

while loop:
  while <condition>(
    ...
  )

for loop (range):
  for i in range(10)(
    say(i)
  )

for loop (list):
  for item in mylist(
    say(item)
  )

Break / continue:
  break
  continue
""",

        "match": """
Match / Case (Switch)
---------------------
  match <expr>(
    case <value>(
      ...
    )
    default(
      ...
    )
  )

Example:
  match cmd(
    case "start"( say("Starting") )
    case "stop"(  say("Stopping") )
    default(      say("Unknown")  )
  )
""",

        "func": """
Functions - def
---------------
Define:
  def greet(name)(
    say(f"Hello {name}")
    return "done"
  )

Call:
  greet("Alice")
  var result = greet("Bob")

Default params:
  def add(a, b = 0)(
    return a + b
  )
""",

        "group": """
Groups - group
--------------
Named blocks of reusable code (no parameters).

  group setup(
    say("Initializing...")
    wait 1
    say("Ready.")
  )

Run with exec:
  exec setup

Groups share the global scope.
""",

        "macro": """
Macros - varcd
--------------
Store a reusable code snippet as a shortcut.

  varcd <name> = <code expression>

Example:
  varcd greet_user = say(f"Hello {name}!/j")

Call:
  name = "Alice"
  greet_user
  exec greet_user
""",

        "math": """
Math and Expressions
--------------------
Arithmetic:  + - * / // % **
Comparison:  == != < > <= >=
Logical:     and  or  not
Bitwise:     &  |  ^  <<  >>

Built-in math functions:
  abs(x)  sqrt(x)  floor(x)  ceil(x)
  min(a, b)  max(a, b)  round(x, n)
  rand()        - random float 0..1
  randint(a, b) - random int in range
  fmt(n)        - format number (2 decimals)
  fmt(n, 4)     - format with 4 decimals
  fmt(n, 2, true) - with thousands separator
""",

        "strings": """
Strings
-------
Plain string:    "hello"  or  'hello'
F-string:        f"Hello {name}, age {age}"
Prompt string:   p"Enter your name: "

Escape sequences:
  /j     - newline
  /j*N   - N newlines
  /t     - tab
  /r     - carriage return
  //     - literal slash

String methods:
  s.upper()         s.lower()         s.strip()
  s.len()           s.replace(a, b)   s.split(sep)
  s.starts(prefix)  s.ends(suffix)    s.find(sub)
  s.slice(i, j)     s.contains(sub)   s.join(list)
  s.as_int()        s.as_float()      s.as_str()
""",

        "input": """
User Input - ask
----------------
  var name = ask(p"Enter your name: ")
  var age  = ask(p"Age: ").as_int()
""",

        "types": """
Type Casting
------------
  .as_int()    - convert to integer
  .as_float()  - convert to float
  .as_str()    - convert to string
  .as_bool()   - convert to boolean

  type(value)  - returns "int", "str", "list", etc.

  fmt(n)           - "3.14"
  fmt(n, 4)        - "3.1416"
  fmt(n, 2, true)  - "1,234.56"
""",

        "listcomp": """
List Comprehensions
-------------------
  [<expr> for <var> in <list>]
  [<expr> for <var> in <list> if <condition>]

Examples:
  var doubled = [x * 2 for x in nums]
  var evens   = [x for x in nums if x % 2 == 0]
  var upper   = [w.upper() for w in words]
""",

        "spread": """
Spread Operator - ...
---------------------
Unpack a list into function arguments.

  var nums   = [1, 2, 3]
  var result = add(...nums)
""",

        "ternary": """
Ternary (Inline If)
-------------------
  <value_if_true> if <condition> else <value_if_false>

Examples:
  var label = "adult" if age >= 18 else "minor"
  var abs_x = x if x >= 0 else -x
""",

        "import": """
Import Nova Modules
-------------------
  import <alias> from <file.nv>

  math.clamp(v, lo, hi)
  exec math.setup

Export from a module:
  export <name>
""",

        "errors": """
Error Handling - try / catch
-----------------------------
  try(
    var x = 1 / 0
  ) catch(err)(
    say(f"Error: {err}")
  )
""",

        "os": """
OS and Shell Integration
------------------------
  shell("ls -la")
  env("HOME")
  setenv("KEY", "value")
  getcwd()
  cd("/path")
  exists("/tmp/file.txt")
  readfile("data.txt")
  writefile("out.txt", "hello")
  appendfile("log.txt", "line")
""",

        "net": """
HTTP Requests
-------------
  var res = http.get("https://api.example.com/data")
  var res = http.post("https://api.example.com", {key: "val"})

  res.get("status")   - HTTP status code
  res.get("body")     - response text
  res.get("json")     - parsed JSON (dict) or null
""",

        "events": """
Event System - on / emit
------------------------
  on <event>(
    say("fired!")
  )
  emit <event>
  emit <event>(<arg1>, <arg2>)

  Inside handler: __args__ holds the argument list.
""",

        "bg": """
Background Tasks - bg
---------------------
  bg(
    wait 5
    say("5 seconds passed!")
  )
  say("main continues immediately")

Threads share the global scope.
""",

        "serial": """
Serial Port / Arduino - serial
-------------------------------
Requires pyserial:
  get pyserial from pip install

  serial.list()
  serial.open("/dev/ttyUSB0", 9600)
  serial.write("/dev/ttyUSB0", "LED_ON")
  var line = serial.readline("/dev/ttyUSB0")
  serial.close("/dev/ttyUSB0")
""",

        "edit": """
Built-in Editor - edit
-----------------------
  edit <file>          - auto-detect editor (default)
  edit <file> auto     - same as above
  edit <file> nova     - force Nova built-in editor

Auto priority:
  Termux  -> micro -> nano -> vi
  Linux   -> $EDITOR -> nano -> vi
  Windows -> notepad
  (fallback to Nova editor if nothing found)

Nova editor keybindings:
  Ctrl+S   - save
  Ctrl+R   - save, run, return to editor
  Ctrl+Q   - quit
  Ctrl+X   - cut line
  Ctrl+V   - paste line
  Ctrl+G   - go to line number
  Ctrl+A   - start of line
  Ctrl+E   - end of line
  Tab      - 4 spaces
""",

        "version": """
Version
-------
Nova language interpreter v{ver}
Python {pyver}
""".format(ver=VERSION, pyver=sys.version.split()[0]),
    }

_build()
