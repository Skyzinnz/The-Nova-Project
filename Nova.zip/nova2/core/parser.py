"""
Nova - Parser: converts token stream to AST
"""

from .lexer import *
from .nodes import *

class ParseError(Exception):
    pass

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos    = 0

    def cur(self): return self.tokens[self.pos]
    def peek(self, offset=1): return self.tokens[min(self.pos+offset, len(self.tokens)-1)]

    def advance(self):
        t = self.tokens[self.pos]
        if self.pos < len(self.tokens)-1:
            self.pos += 1
        return t

    def skip_newlines(self):
        while self.cur().type == TT_NEWLINE:
            self.advance()

    def expect(self, type_, value=None):
        t = self.cur()
        if t.type != type_:
            raise ParseError(f"[Line {t.line}] Expected {type_}, got {t.type} ({t.value!r})")
        if value is not None and t.value != value:
            raise ParseError(f"[Line {t.line}] Expected {value!r}, got {t.value!r}")
        return self.advance()

    def match(self, type_, value=None):
        t = self.cur()
        if t.type != type_:
            return False
        if value is not None and t.value != value:
            return False
        return True

    def consume_if(self, type_, value=None):
        if self.match(type_, value):
            return self.advance()
        return None

    # ---- block: ( ... )
    def parse_block(self):
        self.expect(TT_LPAREN)
        self.skip_newlines()
        stmts = []
        while not self.match(TT_RPAREN) and not self.match(TT_EOF):
            s = self.parse_statement()
            if s:
                stmts.append(s)
            self.skip_newlines()
        self.expect(TT_RPAREN)
        return stmts

    def parse_program(self):
        stmts = []
        self.skip_newlines()
        while not self.match(TT_EOF):
            s = self.parse_statement()
            if s:
                stmts.append(s)
            self.skip_newlines()
        return ProgramNode(stmts)

    def parse_statement(self):
        t = self.cur()

        # skip bare newlines
        if t.type == TT_NEWLINE:
            self.advance()
            return None

        # keywords
        if t.type == TT_KEYWORD:
            kw = t.value

            if kw == "var":
                return self.parse_var()
            if kw == "varcd":
                return self.parse_varcd()
            if kw == "say":
                return self.parse_say()
            if kw == "wait":
                return self.parse_wait()
            if kw == "feed":
                return self.parse_feed()
            if kw == "exec":
                return self.parse_exec()
            if kw == "get":
                return self.parse_get()
            if kw == "help":
                return self.parse_help()
            if kw == "if":
                return self.parse_if()
            if kw == "while":
                return self.parse_while()
            if kw == "for":
                return self.parse_for()
            if kw == "break":
                self.advance(); return BreakNode()
            if kw == "continue":
                self.advance(); return ContinueNode()
            if kw == "return":
                self.advance()
                val = self.parse_expr() if not self.match(TT_NEWLINE) and not self.match(TT_EOF) else NullNode()
                return ReturnNode(val)
            if kw == "def":
                return self.parse_func()
            if kw == "group":
                return self.parse_group()
            if kw == "del":
                self.advance()
                name = self.expect(TT_IDENT).value
                return DelNode(name)
            if kw == "try":
                return self.parse_try()
            if kw == "import":
                return self.parse_import()
            if kw == "export":
                self.advance()
                name = self.expect(TT_IDENT).value
                return ExportNode(name)
            if kw == "const":
                return self.parse_const()
            if kw == "match":
                return self.parse_match()
            if kw == "bg":
                return self.parse_bg()
            if kw == "on":
                return self.parse_on()
            if kw == "emit":
                return self.parse_emit()
            if kw == "serial":
                return self.parse_serial_stmt()
            if kw == "edit":
                return self.parse_edit()

        # ident could be assignment, augmented assign, macro call, or expr
        if t.type == TT_IDENT:
            # look ahead
            nxt = self.peek()
            if nxt.type == TT_OP and nxt.value == "=":
                # simple assign
                name = self.advance().value
                self.advance()  # =
                val  = self.parse_expr()
                return AssignNode(name, val, declare=False)
            if nxt.type == TT_OP and nxt.value in ("+=", "-=", "*=", "/="):
                name = self.advance().value
                op   = self.advance().value
                val  = self.parse_expr()
                return AugAssignNode(name, op, val)
            # check macro call (ident on its own line)
            # We'll handle via expr and let interpreter deal with it

        # expression statement (covers calls, etc.)
        expr = self.parse_expr()

        # augmented assign on attr/index would appear here — skip for now
        return expr

    # ── var ──────────────────────────────────
    def parse_var(self):
        self.expect(TT_KEYWORD, "var")
        name = self.expect(TT_IDENT).value
        self.expect(TT_OP, "=")
        val  = self.parse_expr()
        return AssignNode(name, val, declare=True)

    # ── varcd ─────────────────────────────────
    def parse_varcd(self):
        self.expect(TT_KEYWORD, "varcd")
        name = self.expect(TT_IDENT).value
        self.expect(TT_OP, "=")
        # rest of line is raw code
        code_tokens = []
        while not self.match(TT_NEWLINE) and not self.match(TT_EOF):
            code_tokens.append(self.advance())
        # reconstruct minimal source from tokens
        code = self._tokens_to_source(code_tokens)
        return MacroDefNode(name, code)

    def _tokens_to_source(self, toks):
        parts = []
        for t in toks:
            if t.type == TT_STRING:
                parts.append(f'"{t.value}"')
            elif t.type == TT_FSTRING:
                parts.append(f'f"{t.value}"')
            elif t.type in (TT_INT, TT_FLOAT):
                parts.append(str(t.value))
            elif t.type == TT_BOOL:
                parts.append("true" if t.value else "false")
            elif t.type == TT_NULL:
                parts.append("null")
            elif t.type in (TT_IDENT, TT_KEYWORD):
                parts.append(str(t.value))
            elif t.type == TT_OP:
                parts.append(t.value)
            elif t.type == TT_LPAREN:
                parts.append("(")
            elif t.type == TT_RPAREN:
                parts.append(")")
            elif t.type == TT_COMMA:
                parts.append(",")
            elif t.type == TT_DOT:
                parts.append(".")
            elif t.type == TT_LBRACKET:
                parts.append("[")
            elif t.type == TT_RBRACKET:
                parts.append("]")
            elif t.type == TT_LBRACE:
                parts.append("{")
            elif t.type == TT_RBRACE:
                parts.append("}")
            elif t.type == TT_COLON:
                parts.append(":")
        return " ".join(parts)

    # ── say ──────────────────────────────────
    def parse_say(self):
        self.expect(TT_KEYWORD, "say")
        args = self.parse_call_args_inline()
        return SayNode(args)

    # ── wait ─────────────────────────────────
    def parse_wait(self):
        self.expect(TT_KEYWORD, "wait")
        dur = self.parse_expr()
        return WaitNode(dur)

    # ── feed ─────────────────────────────────
    def parse_feed(self):
        self.expect(TT_KEYWORD, "feed")
        self.expect(TT_DOT)
        mode_tok = self.advance()
        if mode_tok.value not in ("on", "off"):
            raise ParseError(f"feed expects .on or .off")
        return FeedNode(mode_tok.value)

    # ── exec ─────────────────────────────────
    def parse_exec(self):
        self.expect(TT_KEYWORD, "exec")
        if self.match(TT_IDENT):
            target = self.advance().value
            # could be module.group
            if self.match(TT_DOT):
                self.advance()
                sub = self.expect(TT_IDENT).value
                target = target + "." + sub
        elif self.match(TT_STRING):
            target = self.advance().value
        else:
            raise ParseError("exec expects a name or file string")
        return ExecNode(target)

    # ── get ──────────────────────────────────
    def parse_get(self):
        self.expect(TT_KEYWORD, "get")
        name = self.expect(TT_IDENT).value
        self.expect(TT_KEYWORD, "from")
        source_tok = self.advance()
        source = source_tok.value
        mode_tok = self.advance()
        mode = mode_tok.value
        extra = None
        if mode == "url":
            extra = self.advance().value if self.match(TT_STRING) else self.advance().value
            mode = "url"
        elif mode == "git":
            extra = self.advance().value if self.match(TT_STRING) else None
            nxt = self.advance()  # install or var
            mode = nxt.value
        return GetNode(name, source, mode, extra)

    # ── help ─────────────────────────────────
    def parse_help(self):
        self.expect(TT_KEYWORD, "help")
        page = "index"
        # Accept any token as page name (ident or keyword like feed, group, etc.)
        if not self.match(TT_NEWLINE) and not self.match(TT_EOF):
            page = self.advance().value
        return HelpNode(page)

    # ── condition (stops at block-opening paren) ─────
    def parse_condition(self):
        return self._cond_logical()

    def _cond_logical(self):
        left = self._cond_comparison()
        while self.match(TT_KEYWORD, "and") or self.match(TT_KEYWORD, "or"):
            op = self.advance().value
            right = self._cond_comparison()
            left = BinOpNode(left, op, right)
        return left

    def _cond_comparison(self):
        if self.match(TT_KEYWORD, "not"):
            self.advance()
            return UnaryOpNode("not", self._cond_comparison())
        left = self._cond_add()
        while self.match(TT_OP) and self.cur().value in ("==","!=","<",">","<=",">="):
            op = self.advance().value
            right = self._cond_add()
            left = BinOpNode(left, op, right)
        return left

    def _cond_add(self):
        left = self._cond_mul()
        while self.match(TT_OP) and self.cur().value in ("+", "-"):
            op = self.advance().value
            right = self._cond_mul()
            left = BinOpNode(left, op, right)
        return left

    def _cond_mul(self):
        left = self._cond_unary()
        while self.match(TT_OP) and self.cur().value in ("*", "/", "//", "%"):
            op = self.advance().value
            right = self._cond_unary()
            left = BinOpNode(left, op, right)
        return left

    def _cond_unary(self):
        if self.match(TT_OP, "-"):
            self.advance()
            return UnaryOpNode("-", self._cond_unary())
        return self._cond_postfix()

    def _cond_postfix(self):
        """Postfix that does NOT consume a bare ( as a call (it is a block delimiter)."""
        node = self.parse_primary()
        while True:
            if self.match(TT_DOT):
                self.advance()
                attr = self.advance().value
                if self.match(TT_LPAREN):
                    args = self.parse_call_args_inline()
                    node = MethodCallNode(node, attr, args)
                else:
                    node = AttrNode(node, attr)
            elif self.match(TT_LBRACKET):
                self.advance()
                idx = self.parse_expr()
                self.expect(TT_RBRACKET)
                node = IndexNode(node, idx)
            else:
                break
        return node

    # ── if ───────────────────────────────────
    def parse_if(self):
        self.expect(TT_KEYWORD, "if")
        cond  = self.parse_condition()
        body  = self.parse_block()
        branches = [(cond, body)]
        self.skip_newlines()
        while self.match(TT_KEYWORD, "elif"):
            self.advance()
            c = self.parse_condition()
            b = self.parse_block()
            branches.append((c, b))
            self.skip_newlines()
        else_body = None
        if self.match(TT_KEYWORD, "else"):
            self.advance()
            else_body = self.parse_block()
        return IfNode(branches, else_body)

    # ── while ────────────────────────────────
    def parse_while(self):
        self.expect(TT_KEYWORD, "while")
        cond = self.parse_condition()
        body = self.parse_block()
        return WhileNode(cond, body)

    # ── for ──────────────────────────────────
    def parse_for(self):
        self.expect(TT_KEYWORD, "for")
        var = self.expect(TT_IDENT).value
        self.expect(TT_KEYWORD, "in")
        iterable = self._cond_postfix()
        body = self.parse_block()
        return ForNode(var, iterable, body)

    # ── def ──────────────────────────────────
    def parse_func(self):
        self.expect(TT_KEYWORD, "def")
        name = self.expect(TT_IDENT).value
        self.expect(TT_LPAREN)
        params   = []
        defaults = {}
        while not self.match(TT_RPAREN):
            p = self.expect(TT_IDENT).value
            params.append(p)
            if self.consume_if(TT_OP, "="):
                defaults[p] = self.parse_expr()
            self.consume_if(TT_COMMA)
        self.expect(TT_RPAREN)
        body = self.parse_block()
        return FuncDefNode(name, params, defaults, body)

    # ── group ────────────────────────────────
    def parse_group(self):
        self.expect(TT_KEYWORD, "group")
        name = self.expect(TT_IDENT).value
        body = self.parse_block()
        return GroupDefNode(name, body)

    # ── try/catch ────────────────────────────
    def parse_try(self):
        self.expect(TT_KEYWORD, "try")
        try_body = self.parse_block()
        self.skip_newlines()
        self.expect(TT_KEYWORD, "catch")
        self.expect(TT_LPAREN)
        err_var = self.expect(TT_IDENT).value
        self.expect(TT_RPAREN)
        catch_body = self.parse_block()
        return TryCatchNode(try_body, err_var, catch_body)

    # ── const ────────────────────────────────────
    def parse_const(self):
        self.expect(TT_KEYWORD, "const")
        name = self.expect(TT_IDENT).value
        self.expect(TT_OP, "=")
        val  = self.parse_expr()
        return ConstNode(name, val)

    # ── match / case ──────────────────────────
    def parse_match(self):
        self.expect(TT_KEYWORD, "match")
        subject = self.parse_condition()
        self.expect(TT_LPAREN)
        self.skip_newlines()
        cases = []
        default_body = None
        while not self.match(TT_RPAREN) and not self.match(TT_EOF):
            if self.match(TT_KEYWORD, "default"):
                self.advance()
                default_body = self.parse_block()
            elif self.match(TT_KEYWORD, "case"):
                self.advance()
                val = self.parse_condition()  # stops before block-opening (
                body = self.parse_block()
                cases.append((val, body))
            self.skip_newlines()
        self.expect(TT_RPAREN)
        return MatchNode(subject, cases, default_body)

    # ── bg (background task) ──────────────────
    def parse_bg(self):
        self.expect(TT_KEYWORD, "bg")
        body = self.parse_block()
        return BgNode(body)

    # ── on (event listener) ───────────────────
    def parse_on(self):
        self.expect(TT_KEYWORD, "on")
        event = self.advance().value
        body  = self.parse_block()
        return OnNode(event, body)

    # ── emit (fire event) ─────────────────────
    def parse_emit(self):
        self.expect(TT_KEYWORD, "emit")
        event = self.advance().value
        args  = []
        if self.match(TT_LPAREN):
            args = self.parse_call_args_inline()
        return EmitNode(event, args)

    # ── edit ─────────────────────────────────
    def parse_edit(self):
        self.expect(TT_KEYWORD, "edit")
        # filepath: string literal or bare tokens
        if self.match(TT_STRING):
            fp = self.advance().value
        else:
            parts = []
            while not self.match(TT_NEWLINE) and not self.match(TT_EOF) and not (self.match(TT_IDENT) and self.cur().value in ("auto","nova") and len(parts) > 0):
                t = self.advance()
                parts.append("." if t.type == TT_DOT else str(t.value))
            fp = "".join(parts)
        # optional mode: auto | nova
        mode = "auto"
        if self.match(TT_IDENT) and self.cur().value in ("auto", "nova"):
            mode = self.advance().value
        return EditNode(fp, mode)

    # ── serial ────────────────────────────────
    def parse_serial_stmt(self):
        self.expect(TT_KEYWORD, "serial")
        self.expect(TT_DOT)
        action = self.advance().value
        args = []
        if self.match(TT_LPAREN):
            args = self.parse_call_args_inline()
        return SerialNode(action, args)

    # ── import ───────────────────────────────
    def parse_import(self):
        self.expect(TT_KEYWORD, "import")
        alias = self.expect(TT_IDENT).value
        self.expect(TT_KEYWORD, "from")
        # filepath can be a quoted string OR bare tokens like libmath.nv
        if self.match(TT_STRING):
            fp = self.advance().value
        else:
            # collect tokens until newline/EOF as raw filepath
            parts = []
            while not self.match(TT_NEWLINE) and not self.match(TT_EOF):
                t = self.advance()
                if t.type == TT_DOT:
                    parts.append(".")
                else:
                    parts.append(str(t.value))
            fp = "".join(parts)
        return ImportNode(alias, fp)

    # ── call args (inline or multiline) ──────
    def parse_call_args_inline(self):
        """Parse (arg, arg, ...) or multiline ( \n arg \n arg \n ). Supports ...spread"""
        self.expect(TT_LPAREN)
        self.skip_newlines()
        args = []
        while not self.match(TT_RPAREN) and not self.match(TT_EOF):
            # spread: ...expr
            if self.match(TT_OP, ".") or (self.cur().type == TT_DOT):
                # check for triple dot  ... 
                if self.peek(1).type == TT_DOT and self.peek(2).type == TT_DOT:
                    self.advance(); self.advance(); self.advance()
                    args.append(SpreadNode(self.parse_expr()))
                else:
                    args.append(self.parse_expr())
            else:
                args.append(self.parse_expr())
            self.skip_newlines()
            self.consume_if(TT_COMMA)
            self.skip_newlines()
        self.expect(TT_RPAREN)
        return args

    # ── expressions ──────────────────────────
    def parse_expr(self):
        node = self.parse_logical()
        # ternary:  value if condition else other
        if self.match(TT_KEYWORD, "if"):
            self.advance()
            cond     = self.parse_logical()
            self.expect(TT_KEYWORD, "else")
            if_false = self.parse_logical()
            return TernaryNode(cond, node, if_false)
        return node

    def parse_logical(self):
        left = self.parse_bitwise()
        while self.match(TT_KEYWORD, "and") or self.match(TT_KEYWORD, "or"):
            op = self.advance().value
            right = self.parse_bitwise()
            left = BinOpNode(left, op, right)
        return left

    def parse_bitwise(self):
        left = self.parse_comparison()
        while self.match(TT_OP) and self.cur().value in ("&", "|", "^", "<<", ">>"):
            op = self.advance().value
            right = self.parse_comparison()
            left = BinOpNode(left, op, right)
        return left

    def parse_comparison(self):
        if self.match(TT_KEYWORD, "not"):
            self.advance()
            return UnaryOpNode("not", self.parse_comparison())
        left = self.parse_addition()
        while self.match(TT_OP) and self.cur().value in ("==","!=","<",">","<=",">="):
            op = self.advance().value
            right = self.parse_addition()
            left = BinOpNode(left, op, right)
        return left

    def parse_addition(self):
        left = self.parse_multiplication()
        while self.match(TT_OP) and self.cur().value in ("+", "-"):
            op = self.advance().value
            right = self.parse_multiplication()
            left = BinOpNode(left, op, right)
        return left

    def parse_multiplication(self):
        left = self.parse_power()
        while self.match(TT_OP) and self.cur().value in ("*", "/", "//", "%"):
            op = self.advance().value
            right = self.parse_power()
            left = BinOpNode(left, op, right)
        return left

    def parse_power(self):
        left = self.parse_unary()
        if self.match(TT_OP, "**"):
            self.advance()
            right = self.parse_power()
            return BinOpNode(left, "**", right)
        return left

    def parse_unary(self):
        if self.match(TT_OP, "-"):
            self.advance()
            return UnaryOpNode("-", self.parse_unary())
        return self.parse_postfix()

    def parse_postfix(self):
        node = self.parse_primary()
        while True:
            if self.match(TT_DOT):
                self.advance()
                attr = self.advance().value
                if self.match(TT_LPAREN):
                    args = self.parse_call_args_inline()
                    node = MethodCallNode(node, attr, args)
                else:
                    node = AttrNode(node, attr)
            elif self.match(TT_LBRACKET):
                self.advance()
                idx = self.parse_expr()
                self.expect(TT_RBRACKET)
                node = IndexNode(node, idx)
            elif self.match(TT_LPAREN):
                # function call
                args = self.parse_call_args_inline()
                node = CallNode(node, args)
            else:
                break
        return node

    def parse_primary(self):
        t = self.cur()

        if t.type == TT_INT:   self.advance(); return NumberNode(t.value)
        if t.type == TT_FLOAT: self.advance(); return NumberNode(t.value)
        if t.type == TT_BOOL:  self.advance(); return BoolNode(t.value)
        if t.type == TT_NULL:  self.advance(); return NullNode()
        if t.type == TT_STRING: self.advance(); return StringNode(t.value)
        if t.type == TT_FSTRING: self.advance(); return FStringNode(t.value)
        if t.type == TT_PSTRING: self.advance(); return PStringNode(t.value)

        if t.type == TT_LPAREN:
            self.advance()
            self.skip_newlines()
            expr = self.parse_expr()
            self.skip_newlines()
            self.expect(TT_RPAREN)
            return expr

        if t.type == TT_LBRACKET:
            return self.parse_list()

        if t.type == TT_LBRACE:
            return self.parse_dict()

        if t.type == TT_IDENT:
            self.advance()
            return IdentNode(t.value)

        # keyword-as-call builtins: ask, shell, env, setenv, getcwd, cd, exists, readfile, writefile, appendfile
        if t.type == TT_KEYWORD and t.value in (
            "ask","shell","env","setenv","getcwd","cd",
            "exists","readfile","writefile","appendfile",
            "abs","sqrt","floor","ceil","min","max","round",
            "rand","randint","len","str","int","float","bool","type",
            "clear","exit","quit",
            "fmt","serial","bg","emit","on",
        ):
            name = self.advance().value
            if self.match(TT_LPAREN):
                args = self.parse_call_args_inline()
                return CallNode(IdentNode(name), args)
            return IdentNode(name)

        raise ParseError(f"[Line {t.line}] Unexpected token: {t.type} ({t.value!r})")

    def parse_list(self):
        self.expect(TT_LBRACKET)
        self.skip_newlines()
        if self.match(TT_RBRACKET):
            self.advance()
            return ListNode([])
        first = self.parse_expr()
        # list comprehension: [expr for var in iterable]
        if self.match(TT_KEYWORD, "for"):
            self.advance()
            var = self.expect(TT_IDENT).value
            self.expect(TT_KEYWORD, "in")
            iterable = self._cond_postfix()
            cond = None
            if self.match(TT_KEYWORD, "if"):
                self.advance()
                cond = self.parse_condition()
            self.expect(TT_RBRACKET)
            return ListCompNode(first, var, iterable, cond)
        # normal list
        items = [first]
        self.skip_newlines()
        self.consume_if(TT_COMMA)
        self.skip_newlines()
        while not self.match(TT_RBRACKET) and not self.match(TT_EOF):
            items.append(self.parse_expr())
            self.skip_newlines()
            self.consume_if(TT_COMMA)
            self.skip_newlines()
        self.expect(TT_RBRACKET)
        return ListNode(items)

    def parse_dict(self):
        self.expect(TT_LBRACE)
        self.skip_newlines()
        pairs = []
        while not self.match(TT_RBRACE) and not self.match(TT_EOF):
            key = self.parse_primary()
            self.expect(TT_COLON)
            val = self.parse_expr()
            pairs.append((key, val))
            self.skip_newlines()
            self.consume_if(TT_COMMA)
            self.skip_newlines()
        self.expect(TT_RBRACE)
        return DictNode(pairs)


