"""
Nova - Built-in terminal editor with syntax highlight
"""

import curses, curses.ascii, subprocess, shutil, sys, os

# ── Syntax highlight token types ──────────────
_KEYWORDS = {
    "var","varcd","const","say","exec","wait","get","from","import",
    "group","def","return","if","elif","else","while","for","in","range",
    "break","continue","and","or","not","try","catch","del","export",
    "match","case","default","bg","on","emit","serial","feed","ask",
    "shell","env","setenv","getcwd","cd","exists","readfile","writefile",
    "appendfile","help","clear","exit","quit","fmt","http",
}
_BOOL_NULL = {"true","false","null"}

def _hl_tokens(line):
    """
    Tokenize a line for highlight.
    Returns list of (text, category) where category is one of:
    'kw', 'bool', 'str', 'fstr', 'num', 'comment', 'op', 'plain'
    """
    tokens = []
    i = 0
    n = len(line)

    while i < n:
        # block comment start ##
        if line[i] == "#" and i+1 < n and line[i+1] == "#":
            tokens.append((line[i:], "comment"))
            return tokens

        # line comment
        if line[i] == "#":
            tokens.append((line[i:], "comment"))
            return tokens

        # f-string
        if line[i] in ("f","F") and i+1 < n and line[i+1] in ('"', "'"):
            q = line[i+1]
            j = i+2
            while j < n and line[j] != q:
                if line[j] == "\\":
                    j += 1
                j += 1
            j = min(j+1, n)
            tokens.append((line[i:j], "fstr"))
            i = j
            continue

        # p-string
        if line[i] in ("p","P") and i+1 < n and line[i+1] in ('"', "'"):
            q = line[i+1]
            j = i+2
            while j < n and line[j] != q:
                j += 1
            j = min(j+1, n)
            tokens.append((line[i:j], "str"))
            i = j
            continue

        # string
        if line[i] in ('"', "'"):
            q = line[i]
            j = i+1
            while j < n and line[j] != q:
                if line[j] == "\\":
                    j += 1
                j += 1
            j = min(j+1, n)
            tokens.append((line[i:j], "str"))
            i = j
            continue

        # number
        if line[i].isdigit() or (line[i] == "-" and i+1 < n and line[i+1].isdigit()):
            j = i + (1 if line[i] == "-" else 0)
            while j < n and (line[j].isdigit() or line[j] == "."):
                j += 1
            tokens.append((line[i:j], "num"))
            i = j
            continue

        # word (keyword, bool/null, or plain ident)
        if line[i].isalpha() or line[i] == "_":
            j = i
            while j < n and (line[j].isalnum() or line[j] == "_"):
                j += 1
            word = line[i:j]
            if word in _KEYWORDS:
                tokens.append((word, "kw"))
            elif word in _BOOL_NULL:
                tokens.append((word, "bool"))
            else:
                tokens.append((word, "plain"))
            i = j
            continue

        # operator chars
        if line[i] in "+-*/%=<>!&|^~.,:()[]{}":
            tokens.append((line[i], "op"))
            i += 1
            continue

        # anything else (space, tab, etc.)
        tokens.append((line[i], "plain"))
        i += 1

    return tokens


class NovaEditor:
    # color pair IDs
    CP_NORMAL  = 1
    CP_KW      = 2
    CP_STR     = 3
    CP_FSTR    = 4
    CP_NUM     = 5
    CP_COMMENT = 6
    CP_OP      = 7
    CP_BOOL    = 8
    CP_STATUS  = 9
    CP_LINENO  = 10
    CP_TITLE   = 11

    def __init__(self, filepath):
        self.filepath = filepath
        self.lines    = [""]
        self.cx       = 0   # cursor col in line
        self.cy       = 0   # cursor row in lines[]
        self.top      = 0   # first visible line
        self.left     = 0   # first visible col (horizontal scroll)
        self.modified = False
        self.message  = ""
        self.clipboard = ""
        self._load()

    def _load(self):
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                content = f.read()
            self.lines = content.split("\n")
            if self.lines and self.lines[-1] == "":
                self.lines.pop()
            if not self.lines:
                self.lines = [""]
        except FileNotFoundError:
            self.lines    = [""]
            self.modified = True
            self.message  = f"New file: {self.filepath}"

    def _save(self):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                f.write("\n".join(self.lines) + "\n")
            self.modified = False
            self.message  = f"Saved: {self.filepath}"
            return True
        except Exception as e:
            self.message = f"Save error: {e}"
            return False

    def _run_file(self, stdscr):
        """Save and run the file, show output, then return to editor."""
        self._save()
        curses.endwin()
        import sys, os
        print(f"\n\033[1m--- Running {self.filepath} ---\033[0m")
        try:
            result = subprocess.run(
                [sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "__main__.py"),
                 self.filepath],
                text=True
            )
        except Exception as e:
            print(f"Error: {e}")
        print(f"\033[1m--- Press Enter to return to editor ---\033[0m")
        input()
        # re-init curses
        stdscr.refresh()
        curses.doupdate()

    def _setup_colors(self):
        curses.start_color()
        curses.use_default_colors()
        bg = -1
        curses.init_pair(self.CP_NORMAL,  curses.COLOR_WHITE,   bg)
        curses.init_pair(self.CP_KW,      curses.COLOR_CYAN,    bg)
        curses.init_pair(self.CP_STR,     curses.COLOR_GREEN,   bg)
        curses.init_pair(self.CP_FSTR,    curses.COLOR_GREEN,   bg)
        curses.init_pair(self.CP_NUM,     curses.COLOR_YELLOW,  bg)
        curses.init_pair(self.CP_COMMENT, curses.COLOR_WHITE,   bg)   # dim via attr
        curses.init_pair(self.CP_OP,      curses.COLOR_WHITE,   bg)   # bright via attr
        curses.init_pair(self.CP_BOOL,    curses.COLOR_MAGENTA, bg)
        curses.init_pair(self.CP_STATUS,  curses.COLOR_BLACK,   curses.COLOR_CYAN)
        curses.init_pair(self.CP_LINENO,  curses.COLOR_YELLOW,  bg)
        curses.init_pair(self.CP_TITLE,   curses.COLOR_BLACK,   curses.COLOR_BLUE)

    def _cat(self, cat):
        """Return (color_pair_attr, extra_attr) for a token category."""
        if cat == "kw":      return curses.color_pair(self.CP_KW)    | curses.A_BOLD
        if cat == "str":     return curses.color_pair(self.CP_STR)
        if cat == "fstr":    return curses.color_pair(self.CP_FSTR)  | curses.A_BOLD
        if cat == "num":     return curses.color_pair(self.CP_NUM)
        if cat == "comment": return curses.color_pair(self.CP_COMMENT)| curses.A_DIM
        if cat == "op":      return curses.color_pair(self.CP_OP)    | curses.A_BOLD
        if cat == "bool":    return curses.color_pair(self.CP_BOOL)  | curses.A_BOLD
        return curses.color_pair(self.CP_NORMAL)

    def _draw(self, stdscr):
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        LNOW   = 5   # line number column width
        EDTW   = w - LNOW   # editable area width
        # reserve top 1 row (title) + bottom 2 rows (status + keys)
        ROWS   = h - 3

        # ── title bar ─────────────────────────────
        mod    = " [+]" if self.modified else "    "
        title  = f" Nova Editor  {self.filepath}{mod}"
        title  = title[:w].ljust(w)
        try:
            stdscr.addstr(0, 0, title, curses.color_pair(self.CP_TITLE) | curses.A_BOLD)
        except curses.error:
            pass

        # ── code lines ────────────────────────────
        for row in range(ROWS):
            lnum = self.top + row
            scr_row = row + 1   # offset by title bar

            if lnum >= len(self.lines):
                try:
                    stdscr.addstr(scr_row, 0, "~" + " " * (w - 1),
                                  curses.color_pair(self.CP_COMMENT) | curses.A_DIM)
                except curses.error:
                    pass
                continue

            # line number
            ln_str = f"{lnum+1:>{LNOW-1}} "
            try:
                stdscr.addstr(scr_row, 0, ln_str, curses.color_pair(self.CP_LINENO))
            except curses.error:
                pass

            # code with syntax highlight
            line    = self.lines[lnum]
            visible = line[self.left:self.left + EDTW]
            tokens  = _hl_tokens(visible)
            col     = LNOW
            for text, cat in tokens:
                if col >= w - 1:
                    break
                avail = w - 1 - col
                chunk = text[:avail]
                try:
                    stdscr.addstr(scr_row, col, chunk, self._cat(cat))
                except curses.error:
                    pass
                col += len(chunk)

        # ── status bar ────────────────────────────
        pos_info = f" Ln {self.cy+1}/{len(self.lines)}  Col {self.cx+1} "
        msg      = self.message[:w - len(pos_info) - 2]
        status   = f" {msg}".ljust(w - len(pos_info)) + pos_info
        status   = status[:w]
        try:
            stdscr.addstr(h-2, 0, status, curses.color_pair(self.CP_STATUS))
        except curses.error:
            pass

        # ── key hints ─────────────────────────────
        hints = " ^S Save  ^R Run  ^Q Quit  ^X Cut  ^V Paste  ^A SelectAll"
        hints = hints[:w-1].ljust(w-1)
        try:
            stdscr.addstr(h-1, 0, hints, curses.color_pair(self.CP_COMMENT) | curses.A_DIM)
        except curses.error:
            pass

        # ── position cursor ───────────────────────
        cur_scr_row = (self.cy - self.top) + 1
        cur_scr_col = (self.cx - self.left) + LNOW
        try:
            stdscr.move(cur_scr_row, cur_scr_col)
        except curses.error:
            pass

        stdscr.refresh()

    def _scroll(self, stdscr):
        h, w = stdscr.getmaxyx()
        ROWS  = h - 3
        LNOW  = 5
        EDTW  = w - LNOW

        if self.cy < self.top:
            self.top = self.cy
        if self.cy >= self.top + ROWS:
            self.top = self.cy - ROWS + 1

        if self.cx < self.left:
            self.left = self.cx
        if self.cx >= self.left + EDTW:
            self.left = self.cx - EDTW + 1

    def _clamp_cx(self):
        line_len = len(self.lines[self.cy])
        if self.cx > line_len:
            self.cx = line_len

    def run(self, stdscr):
        self._setup_colors()
        curses.curs_set(1)
        stdscr.keypad(True)

        while True:
            self._scroll(stdscr)
            self._draw(stdscr)
            key = stdscr.get_wch()

            # ── Ctrl keys ─────────────────────────
            if key == curses.ascii.ctrl(ord("q")):
                if self.modified:
                    self.message = "Unsaved changes! ^Q again to quit without saving."
                    self._draw(stdscr)
                    k2 = stdscr.get_wch()
                    if k2 == curses.ascii.ctrl(ord("q")):
                        break
                else:
                    break

            elif key == curses.ascii.ctrl(ord("s")):
                self._save()

            elif key == curses.ascii.ctrl(ord("r")):
                self._run_file(stdscr)
                # re-setup after returning
                self._setup_colors()
                curses.curs_set(1)
                stdscr.keypad(True)
                stdscr.clear()
                self.message = f"Ran {self.filepath}"

            elif key == curses.ascii.ctrl(ord("x")):
                # cut current line
                self.clipboard = self.lines[self.cy]
                self.lines.pop(self.cy)
                if not self.lines:
                    self.lines = [""]
                if self.cy >= len(self.lines):
                    self.cy = len(self.lines) - 1
                self.cx = 0
                self.modified = True
                self.message  = "Line cut"

            elif key == curses.ascii.ctrl(ord("v")):
                # paste before current line
                self.lines.insert(self.cy, self.clipboard)
                self.modified = True
                self.message  = "Pasted"

            elif key == curses.ascii.ctrl(ord("a")):
                # go to start of line
                self.cx = 0

            elif key == curses.ascii.ctrl(ord("e")):
                # go to end of line
                self.cx = len(self.lines[self.cy])

            elif key == curses.ascii.ctrl(ord("g")):
                # go to line N  (prompt in status)
                self.message = "Go to line: "
                self._draw(stdscr)
                curses.echo()
                inp = stdscr.getstr(stdscr.getmaxyx()[0]-2, 14, 6).decode("utf-8", errors="replace")
                curses.noecho()
                try:
                    n = int(inp) - 1
                    self.cy = max(0, min(n, len(self.lines)-1))
                    self.cx = 0
                    self.message = f"Jumped to line {n+1}"
                except ValueError:
                    self.message = "Invalid line number"

            # ── navigation ────────────────────────
            elif key == curses.KEY_UP:
                if self.cy > 0:
                    self.cy -= 1
                    self._clamp_cx()
            elif key == curses.KEY_DOWN:
                if self.cy < len(self.lines) - 1:
                    self.cy += 1
                    self._clamp_cx()
            elif key == curses.KEY_LEFT:
                if self.cx > 0:
                    self.cx -= 1
                elif self.cy > 0:
                    self.cy -= 1
                    self.cx = len(self.lines[self.cy])
            elif key == curses.KEY_RIGHT:
                if self.cx < len(self.lines[self.cy]):
                    self.cx += 1
                elif self.cy < len(self.lines) - 1:
                    self.cy += 1
                    self.cx = 0
            elif key == curses.KEY_HOME:
                self.cx = 0
            elif key == curses.KEY_END:
                self.cx = len(self.lines[self.cy])
            elif key == curses.KEY_PPAGE:  # Page Up
                self.cy = max(0, self.cy - 20)
                self._clamp_cx()
            elif key == curses.KEY_NPAGE:  # Page Down
                self.cy = min(len(self.lines)-1, self.cy + 20)
                self._clamp_cx()

            # ── editing ───────────────────────────
            elif key in (curses.KEY_BACKSPACE, curses.ascii.BS, 127):
                if self.cx > 0:
                    line = self.lines[self.cy]
                    self.lines[self.cy] = line[:self.cx-1] + line[self.cx:]
                    self.cx -= 1
                    self.modified = True
                elif self.cy > 0:
                    prev = self.lines[self.cy - 1]
                    curr = self.lines[self.cy]
                    self.cx = len(prev)
                    self.lines[self.cy - 1] = prev + curr
                    self.lines.pop(self.cy)
                    self.cy -= 1
                    self.modified = True

            elif key == curses.KEY_DC:  # Delete
                line = self.lines[self.cy]
                if self.cx < len(line):
                    self.lines[self.cy] = line[:self.cx] + line[self.cx+1:]
                    self.modified = True
                elif self.cy < len(self.lines) - 1:
                    self.lines[self.cy] = line + self.lines[self.cy+1]
                    self.lines.pop(self.cy+1)
                    self.modified = True

            elif key in (ord("\n"), ord("\r"), curses.KEY_ENTER, 10, 13):
                line = self.lines[self.cy]
                self.lines[self.cy]       = line[:self.cx]
                self.lines.insert(self.cy+1, line[self.cx:])
                self.cy += 1
                self.cx  = 0
                self.modified = True

            elif key == ord("\t"):
                # insert 4 spaces
                line = self.lines[self.cy]
                self.lines[self.cy] = line[:self.cx] + "    " + line[self.cx:]
                self.cx += 4
                self.modified = True

            elif isinstance(key, str) and key.isprintable():
                line = self.lines[self.cy]
                self.lines[self.cy] = line[:self.cx] + key + line[self.cx:]
                self.cx += 1
                self.modified = True

            elif isinstance(key, int) and 32 <= key < 127:
                ch   = chr(key)
                line = self.lines[self.cy]
                self.lines[self.cy] = line[:self.cx] + ch + line[self.cx:]
                self.cx += 1
                self.modified = True


def _open_system_editor(filepath):
    """Try to open a system editor. Returns True if successful."""
    import sys, os
    system = sys.platform

    # Termux
    if "TERMUX_VERSION" in os.environ or os.path.exists("/data/data/com.termux"):
        for ed in ("micro", "nano", "vi", "vim"):
            if shutil.which(ed):
                subprocess.run([ed, filepath])
                return True

    if system == "win32":
        subprocess.run(["notepad", filepath])
        return True

    if system == "darwin":
        ed = os.environ.get("EDITOR", "")
        if ed and shutil.which(ed):
            subprocess.run([ed, filepath])
            return True
        subprocess.run(["open", "-t", filepath])
        return True

    # Linux generic
    ed = os.environ.get("EDITOR", "")
    if ed and shutil.which(ed):
        subprocess.run([ed, filepath])
        return True
    for ed in ("micro", "nano", "vi", "vim"):
        if shutil.which(ed):
            subprocess.run([ed, filepath])
            return True

    return False


def nova_edit(filepath, mode="auto"):
    """
    Entry point for the Nova editor command.
    mode: "auto" | "nova"
    """
    if mode == "nova":
        try:
            curses.wrapper(lambda stdscr: NovaEditor(filepath).run(stdscr))
        except Exception as e:
            print(f"Editor error: {e}")
        return

    # auto: try system first, fall back to nova
    if mode == "auto":
        opened = _open_system_editor(filepath)
        if not opened:
            try:
                curses.wrapper(lambda stdscr: NovaEditor(filepath).run(stdscr))
            except Exception as e:
                print(f"Editor error: {e}")


