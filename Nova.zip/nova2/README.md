# Nova Programming Language

A general-purpose interpreted language designed for systems, game scripting, and physical project automation.

## Quick Start

### Linux / Termux (Android)
```bash
bash install.sh
nova --version
nova myfile.nv
```

### Windows
Run `install.bat` as Administrator (or double-click it).
Then open a new Command Prompt:
```cmd
nova --version
nova myfile.nv
```

## Usage
```
nova                       Start the REPL
nova <file.nv>             Run a file
nova edit <file.nv>        Open file in editor (auto-detect)
nova edit <file.nv> nova   Force built-in editor
nova --version             Show version
```

## File structure
```
Nova/
  nova.py         Entry point
  core/
    __init__.py
    help.py       Help pages
    lexer.py      Tokenizer
    nodes.py      AST nodes
    parser.py     Parser
    runtime.py    Scope and signals
    interpreter.py Interpreter and builtins
    editor.py     Built-in terminal editor
  install.sh      Linux / Termux installer
  install.bat     Windows installer
```

## In-language help
```nova
help
help vars
help flow
help edit
help serial
```
